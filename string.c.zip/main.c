# include <stdio.h>
void main()
{
    char a[50];
    int l=0;
    printf("enter the string :");
    gets(a);
    for( int i=0;a[i]!= \'0';i++);
    l++;
    printf("lenth of the string is :%d",l);
    
}